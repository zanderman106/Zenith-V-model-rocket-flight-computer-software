#pragma once
#include <Arduino.h>

// Selects the pin map from camera_pins.h. Freenove's own C tutorial
// (downloadable from their product page, fnk0085) has the pins tested
// against this exact board under Chapter 7 "Camera Web Server" -- if
// your installed ESP32 core doesn't recognize this define, pull the
// #define and camera_pins.h from that example instead of guessing pin
// numbers here. camera_pins.h must sit alongside this file in the
// sketch folder (it ships with the ESP32 Arduino core examples).
#define CAMERA_MODEL_FREENOVE_ESP32S3_CAM
#include "camera_pins.h"
#include <esp_camera.h>

class CameraRecorder {
 public:
  bool begin();
  void startRecording();
  void captureFrame();
  void stopRecording();
  bool ok() const { return _ok; }

 private:
  bool _ok = false;
  volatile bool _recording = false;
  uint32_t _flightDirIndex = 0;
  uint32_t _frameIndex = 0;
  char _currentDir[48] = {0};
};

extern CameraRecorder camera;

// Set true/false from the main loop to start/stop video recording;
// cameraTask (core 0) picks up the change and drives the camera so SD
// writes never stall the telemetry loop on core 1.
extern volatile bool g_shouldRecord;
extern TaskHandle_t cameraTaskHandle;

void cameraTask(void* pvParameters);

// Call once from setup() to launch cameraTask pinned to core 0.
void startCameraTask();
