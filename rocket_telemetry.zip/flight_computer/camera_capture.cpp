#include "camera_capture.h"
#include "config.h"
#include <SD_MMC.h>

CameraRecorder camera;
volatile bool g_shouldRecord = false;
TaskHandle_t cameraTaskHandle = nullptr;

bool CameraRecorder::begin() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  if (psramFound()) {
    config.frame_size = FRAMESIZE_VGA;   // 640x480
    config.jpeg_quality = 12;
    config.fb_count = 2;
    config.fb_location = CAMERA_FB_IN_PSRAM;
  } else {
    config.frame_size = FRAMESIZE_QVGA;  // 320x240
    config.jpeg_quality = 15;
    config.fb_count = 1;
    config.fb_location = CAMERA_FB_IN_DRAM;
  }
  config.grab_mode = CAMERA_GRAB_LATEST;

  esp_err_t err = esp_camera_init(&config);
  _ok = (err == ESP_OK);
  return _ok;
}

void CameraRecorder::startRecording() {
  if (!_ok || _recording) return;
  _flightDirIndex++;
  _frameIndex = 0;
  snprintf(_currentDir, sizeof(_currentDir), "%s/flight_%03lu", VIDEO_DIR, (unsigned long)_flightDirIndex);
  if (!SD_MMC.exists(VIDEO_DIR)) SD_MMC.mkdir(VIDEO_DIR);
  SD_MMC.mkdir(_currentDir);
  _recording = true;
}

void CameraRecorder::captureFrame() {
  if (!_ok || !_recording) return;
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) return;

  char path[80];
  snprintf(path, sizeof(path), "%s/frame_%05lu.jpg", _currentDir, (unsigned long)_frameIndex);
  File f = SD_MMC.open(path, FILE_WRITE);
  if (f) {
    f.write(fb->buf, fb->len);
    f.close();
    _frameIndex++;
  }
  esp_camera_fb_return(fb);
}

void CameraRecorder::stopRecording() { _recording = false; }

void cameraTask(void* pvParameters) {
  bool wasRecording = false;
  for (;;) {
    if (g_shouldRecord && !wasRecording) {
      camera.startRecording();
      wasRecording = true;
    } else if (!g_shouldRecord && wasRecording) {
      camera.stopRecording();
      wasRecording = false;
    }
    if (wasRecording) camera.captureFrame();
    vTaskDelay(pdMS_TO_TICKS(VIDEO_FRAME_INTERVAL_MS));
  }
}

void startCameraTask() {
  xTaskCreatePinnedToCore(cameraTask, "cameraTask", 8192, nullptr, 1, &cameraTaskHandle, 0);
}
