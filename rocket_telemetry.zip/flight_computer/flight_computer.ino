// =============================================================================
// ROCKET FLIGHT COMPUTER
// Board: Freenove ESP32-S3-CAM
// Arduino IDE board setting: "ESP32S3 Dev Module"
//
// Reads BMP388 + NEO-M8N GPS, tracks flight state, logs CSV + records video
// to the included SD card, sends LoRa telemetry. Camera capture runs on CPU
// core 0 as a separate task (camera_capture.cpp) so SD writes never stall
// the telemetry loop on core 1. No pyro/deployment channels in this build.
//
// REQUIRED LIBRARIES (install via Library Manager):
//   - Adafruit BMP3XX Library  (+ dependency: Adafruit BusIO)
//   - TinyGPSPlus
//   - LoRa  (by Sandeep Mistry)
//   SD_MMC and esp_camera ship with the ESP32 Arduino core -- nothing to
//   install for those.
//
// FILES IN THIS SKETCH:
//   config.h           - all pin numbers and tunable constants
//   telemetry.h         - wire-format struct, shared with ground_station/
//   camera_capture.h/.cpp - camera pin map, CameraRecorder, core-0 task
//   flight_computer.ino   - this file: sensors, state machine, setup/loop
//
// SD_MMC PINS: this board uses SDMMC 1-bit mode via the built-in SD_MMC.h
// library. SD_MMC.begin("/sdcard", true) below relies on default pin
// detection; if that fails on your board, copy the exact
// SD_MMC.setPins(...) call from Freenove's Chapter 4 "SDMMC Test" example,
// which is tested against this specific board revision.
//
// VIDEO FORMAT: frames save as frame_00001.jpg, frame_00002.jpg, ... inside
// a new flight_NNN folder each recording, rather than one big container --
// a mid-flight SD error then only costs the last frame or two. Stitch to
// video afterward with:
//   ffmpeg -framerate 10 -i frame_%05d.jpg -pix_fmt yuv420p flight.mp4
//
// WHY NO LIVE VIDEO OVER LORA: LoRa tops out around a few kbps, nowhere
// near enough for video. Telemetry (altitude, GPS, battery) goes over
// LoRa; video is recorded onboard and recovered after the flight instead,
// which is reliable regardless of altitude or line-of-sight.
// =============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <SD_MMC.h>
#include <FS.h>
#include <Adafruit_BMP3XX.h>   // Library Manager: "Adafruit BMP3XX Library"
#include <TinyGPSPlus.h>       // Library Manager: "TinyGPSPlus"
#include <LoRa.h>              // Library Manager: "LoRa" by Sandeep Mistry

#include "config.h"
#include "telemetry.h"
#include "camera_capture.h"

// -----------------------------------------------------------------------
// FLIGHT STATE MACHINE -- no pyro/deployment channels in this build.
// States drive telemetry rate and video start/stop, not recovery.
// -----------------------------------------------------------------------
enum FlightState : uint8_t {
  STATE_PAD = 0,
  STATE_POWERED_ASCENT = 1,
  STATE_COAST = 2,
  STATE_APOGEE = 3,
  STATE_DESCENT = 4,
  STATE_LANDED = 5,
};

const char* flightStateName(FlightState s) {
  switch (s) {
    case STATE_PAD: return "PAD";
    case STATE_POWERED_ASCENT: return "POWERED_ASCENT";
    case STATE_COAST: return "COAST";
    case STATE_APOGEE: return "APOGEE";
    case STATE_DESCENT: return "DESCENT";
    case STATE_LANDED: return "LANDED";
    default: return "?";
  }
}

class FlightStateMachine {
 public:
  FlightStateMachine()
      : _state(STATE_PAD), _fallingCount(0), _landedStableMs(0),
        _lastAltitude(0.0f), _maxAltitude(0.0f) {}

  bool update(float altitudeM, float verticalSpeedMps, uint32_t dtMs) {
    FlightState prev = _state;
    if (altitudeM > _maxAltitude) _maxAltitude = altitudeM;

    switch (_state) {
      case STATE_PAD:
        if (verticalSpeedMps > LAUNCH_RATE_THRESHOLD_MPS) {
          _state = STATE_POWERED_ASCENT;
        }
        break;

      case STATE_POWERED_ASCENT:
        if (verticalSpeedMps <= 0 || verticalSpeedMps < LAUNCH_RATE_THRESHOLD_MPS * 0.5f) {
          _state = STATE_COAST;  // burnout: still climbing but no longer accelerating hard
        }
        break;

      case STATE_COAST:
        if (verticalSpeedMps < 0) {
          _fallingCount++;
          if (_fallingCount >= APOGEE_CONFIRM_SAMPLES) _state = STATE_APOGEE;
        } else {
          _fallingCount = 0;
        }
        break;

      case STATE_APOGEE:
        _state = STATE_DESCENT;  // single-tick transition state
        break;

      case STATE_DESCENT: {
        bool nearGround = fabsf(altitudeM - _lastAltitude) < LANDED_ALT_WINDOW_M;
        if (nearGround && altitudeM < 3.0f) {
          _landedStableMs += dtMs;
          if (_landedStableMs >= (uint32_t)LANDED_STILL_SECONDS * 1000) {
            _state = STATE_LANDED;
          }
        } else {
          _landedStableMs = 0;
        }
        break;
      }

      case STATE_LANDED:
        break;
    }

    _lastAltitude = altitudeM;
    return _state != prev;
  }

  FlightState state() const { return _state; }
  float maxAltitudeM() const { return _maxAltitude; }

 private:
  FlightState _state;
  int _fallingCount;
  uint32_t _landedStableMs;
  float _lastAltitude;
  float _maxAltitude;
};

// -----------------------------------------------------------------------
// BAROMETER (BMP388)
// -----------------------------------------------------------------------
class Barometer {
 public:
  bool begin() {
    Wire.begin(BARO_SDA_PIN, BARO_SCL_PIN);
    _ok = _bmp.begin_I2C(BARO_I2C_ADDR, &Wire);
    if (_ok) {
      _bmp.setTemperatureOversampling(BMP3_OVERSAMPLING_2X);
      _bmp.setPressureOversampling(BMP3_OVERSAMPLING_8X);
      _bmp.setIIRFilterCoeff(BMP3_IIR_FILTER_COEFF_3);
      _bmp.setOutputDataRate(BMP3_ODR_50_HZ);
    }
    return _ok;
  }

  void calibrate(int samples = 20, int delayMs = 50) {
    if (!_ok) return;
    double total = 0;
    for (int i = 0; i < samples; i++) {
      _bmp.performReading();
      total += _bmp.pressure;
      delay(delayMs);
    }
    _seaLevelPa = total / samples;
  }

  float readAltitudeM() {
    if (!_ok) return 0.0f;
    if (!_bmp.performReading()) return 0.0f;
    return 44330.0f * (1.0f - powf(_bmp.pressure / _seaLevelPa, 0.1903f));
  }

  bool ok() const { return _ok; }

 private:
  Adafruit_BMP3XX _bmp;
  float _seaLevelPa = 101325.0f;
  bool _ok = false;
};

// -----------------------------------------------------------------------
// GPS (NEO-M8N via TinyGPS++)
// -----------------------------------------------------------------------
class GPSReceiver {
 public:
  void begin() {
    _serial = &Serial1;
    _serial->begin(GPS_BAUD, SERIAL_8N1, GPS_RX_PIN, GPS_TX_PIN);
  }

  void poll() {
    while (_serial->available()) {
      _gps.encode(_serial->read());
    }
    fix = _gps.location.isValid() && _gps.location.isUpdated();
    if (_gps.location.isValid()) {
      lat = _gps.location.lat();
      lon = _gps.location.lng();
    }
    if (_gps.satellites.isValid()) {
      satellites = _gps.satellites.value();
    }
  }

  bool fix = false;
  double lat = 0.0;
  double lon = 0.0;
  uint32_t satellites = 0;

 private:
  TinyGPSPlus _gps;
  HardwareSerial* _serial = nullptr;
};

// -----------------------------------------------------------------------
// LORA RADIO (SX1276 via the Sandeep Mistry LoRa library)
// -----------------------------------------------------------------------
class LoRaLink {
 public:
  bool begin(int csPin, int rstPin, int dio0Pin, long freqHz, int txPowerDbm) {
    LoRa.setPins(csPin, rstPin, dio0Pin);
    _ok = LoRa.begin(freqHz);
    if (_ok) LoRa.setTxPower(txPowerDbm);
    return _ok;
  }

  bool send(const uint8_t* data, size_t len) {
    if (!_ok) return false;
    LoRa.beginPacket();
    LoRa.write(data, len);
    return LoRa.endPacket() == 1;
  }

  bool ok() const { return _ok; }

 private:
  bool _ok = false;
};

// -----------------------------------------------------------------------
// FLIGHT LOG (CSV to SD card)
// -----------------------------------------------------------------------
class FlightLog {
 public:
  bool begin(const char* path) {
    bool isNew = !SD_MMC.exists(path);
    _file = SD_MMC.open(path, FILE_APPEND);
    if (!_file) return false;
    if (isNew) {
      _file.println("time_ms,state,altitude_m,vspeed_mps,lat,lon,battery_v");
      _file.flush();
    }
    return true;
  }

  void write(uint32_t timeMs, const char* stateName, float altitudeM,
             float vSpeedMps, double lat, double lon, float batteryV) {
    if (!_file) return;
    _file.printf("%lu,%s,%.2f,%.2f,%.6f,%.6f,%.2f\n",
                 (unsigned long)timeMs, stateName, altitudeM, vSpeedMps, lat, lon, batteryV);
    if (++_pending >= kFlushEvery) {
      _file.flush();
      _pending = 0;
    }
  }

  void close() {
    if (_file) {
      _file.flush();
      _file.close();
    }
  }

 private:
  File _file;
  int _pending = 0;
  static const int kFlushEvery = 10;
};

// -----------------------------------------------------------------------
// MAIN
// -----------------------------------------------------------------------
Barometer baro;
GPSReceiver gps;
LoRaLink lora;
FlightLog flightLog;
FlightStateMachine fsm;
// `camera`, `g_shouldRecord`, and the core-0 task live in camera_capture.cpp

float readBatteryVoltage() {
  int raw = analogRead(BATTERY_ADC_PIN);
  float pinVoltage = (raw / 4095.0f) * 3.3f;  // 12-bit ADC, 3.3V reference
  return pinVoltage * BATTERY_DIVIDER_RATIO;
}

void setup() {
  Serial.begin(115200);
  delay(500);

  if (!SD_MMC.begin("/sdcard", true)) {  // true = 1-bit mode, matches this board
    Serial.println("SD_MMC init failed -- check wiring/pins against Freenove's example.");
  }

  Serial.print("Barometer: ");
  Serial.println(baro.begin() ? "ok" : "FAILED");

  gps.begin();

  Serial.print("LoRa: ");
  bool loraOk = lora.begin(LORA_CS_PIN, LORA_RST_PIN, LORA_DIO0_PIN, LORA_FREQ_HZ, LORA_TX_POWER_DBM);
  Serial.println(loraOk ? "ok" : "FAILED");

  Serial.print("Camera: ");
  Serial.println(camera.begin() ? "ok" : "FAILED (video disabled this flight)");

  if (!flightLog.begin(LOG_FILE_PATH)) {
    Serial.println("Flight log open failed.");
  }

  Serial.println("Calibrating barometer to ground level, hold still...");
  baro.calibrate();
  Serial.println("Ready.");

  startCameraTask();
}

uint32_t lastLoopMs = 0;
float lastAltitude = 0.0f;

void loop() {
  uint32_t nowMs = millis();
  uint32_t dtMs = nowMs - lastLoopMs;
  lastLoopMs = nowMs;

  gps.poll();
  float altitudeM = baro.readAltitudeM();
  float verticalSpeed = (dtMs > 0) ? (altitudeM - lastAltitude) / (dtMs / 1000.0f) : 0.0f;
  lastAltitude = altitudeM;

  bool changed = fsm.update(altitudeM, verticalSpeed, dtMs);
  if (changed) {
    Serial.print("State -> ");
    Serial.println(flightStateName(fsm.state()));

    if (VIDEO_ENABLED && fsm.state() == STATE_POWERED_ASCENT) {
      g_shouldRecord = true;
    }
    if (fsm.state() == STATE_LANDED) {
      g_shouldRecord = false;
    }
  }

  float batteryV = readBatteryVoltage();

  flightLog.write(nowMs, flightStateName(fsm.state()), altitudeM, verticalSpeed,
                   gps.lat, gps.lon, batteryV);

  TelemetryPacket pkt;
  pkt.flight_state = (uint8_t)fsm.state();
  pkt.time_ms = nowMs;
  pkt.altitude_m = altitudeM;
  pkt.vertical_speed_mps = verticalSpeed;
  pkt.lat = (float)gps.lat;
  pkt.lon = (float)gps.lon;
  pkt.battery_v = batteryV;
  telemetryFinalize(pkt);
  lora.send((const uint8_t*)&pkt, sizeof(pkt));

  bool flying = (fsm.state() == STATE_POWERED_ASCENT || fsm.state() == STATE_COAST ||
                 fsm.state() == STATE_DESCENT);
  int rateHz = flying ? TELEMETRY_RATE_HZ_FLIGHT : TELEMETRY_RATE_HZ_PAD;
  delay(1000 / rateHz);
}
