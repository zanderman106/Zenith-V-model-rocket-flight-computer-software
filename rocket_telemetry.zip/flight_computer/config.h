#pragma once

// -----------------------------------------------------------------------
// CONFIG -- edit pin numbers and constants to match your actual wiring
// -----------------------------------------------------------------------
// These GPIOs were picked to avoid every pin already claimed elsewhere
// on the Freenove ESP32-S3-CAM (ESP32-S3-WROOM-1 R8 module):
//   - camera (CAMERA_MODEL_FREENOVE_ESP32S3_CAM): 4,5,6,7,8,9,10,11,12,13,15,16,17,18
//   - SD_MMC 1-bit mode:                          38,39,40
//   - onboard WS2812 status LED:                  48
//   - internal flash SPI (never exposed on WROOM-1 modules): 26-32
//   - octal PSRAM, used by the R8 variant on this board:     33-37
//   - native USB D-/D+:                           19,20
//   - UART0 (Serial / flashing):                  43,44
//   - boot-strapping pins (avoided even though usable): 0,3,45,46
//
// The previous version of this file reused 4,8,9,10,11,12,13,17,18 --
// all of which the camera driver also owns -- which is why the
// barometer/GPS/LoRa/battery readings were unreliable or the board
// hung on boot. Verify this map against Freenove's own schematic
// before you wire anything permanently; GPIO21 in particular has a
// board-specific role during some Freenove ESP32-S3 boot/flash
// workflows, so double-check it's free for plain GPIO use on your
// specific board revision.

// I2C bus (BMP388 barometer)
#define BARO_SDA_PIN      2
#define BARO_SCL_PIN      14
#define BARO_I2C_ADDR     0x77   // 0x76 if SDO is tied low

// UART for GPS (NEO-M8N, NMEA @ 9600 baud default)
#define GPS_RX_PIN        42     // ESP32 RX <- GPS TX
#define GPS_TX_PIN        41     // ESP32 TX -> GPS RX
#define GPS_BAUD          9600

// SPI for LoRa (SX1276)
#define LORA_SCK_PIN      21
#define LORA_MISO_PIN     22
#define LORA_MOSI_PIN     23
#define LORA_CS_PIN       24
#define LORA_RST_PIN      25
#define LORA_DIO0_PIN     47
#define LORA_FREQ_HZ      915E6
#define LORA_TX_POWER_DBM 17     // keep <= module's rated max

// Battery voltage sense (through a resistor divider into an ADC pin)
// Must be an ADC-capable pin: GPIO1-10 (ADC1) or GPIO11-20 (ADC2) on ESP32-S3.
#define BATTERY_ADC_PIN       1
#define BATTERY_DIVIDER_RATIO 2.0f  // (R1+R2)/R2 -- set to match your divider

// Video
#define VIDEO_ENABLED           true
#define VIDEO_DIR               "/video"     // folder on the SD card
#define VIDEO_FRAME_INTERVAL_MS 100          // ~10 fps

// Flight state machine thresholds
#define LAUNCH_RATE_THRESHOLD_MPS  8.0f
#define APOGEE_CONFIRM_SAMPLES     3
#define LANDED_ALT_WINDOW_M        2.0f
#define LANDED_STILL_SECONDS       10

// Telemetry / logging rates
#define TELEMETRY_RATE_HZ_PAD     1
#define TELEMETRY_RATE_HZ_FLIGHT  5
#define LOG_FILE_PATH             "/flightlog.csv"
