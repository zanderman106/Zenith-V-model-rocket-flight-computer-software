#pragma once
#include <Arduino.h>

// -----------------------------------------------------------------------
// TELEMETRY WIRE FORMAT -- this file is the single source of truth for
// the packet layout. Keep it byte-for-byte identical in both
// flight_computer/ and ground_station/, or encode/decode will drift.
// -----------------------------------------------------------------------
#define TELEMETRY_PACKET_TYPE 1

#pragma pack(push, 1)
struct TelemetryPacket {
  uint8_t  packet_type;
  uint8_t  flight_state;
  uint32_t time_ms;
  float    altitude_m;
  float    vertical_speed_mps;
  float    lat;
  float    lon;
  float    battery_v;
  uint16_t checksum;
};
#pragma pack(pop)

inline uint16_t telemetryChecksum(const uint8_t* bytes, size_t len) {
  uint32_t sum = 0;
  for (size_t i = 0; i < len; i++) sum += bytes[i];
  return (uint16_t)(sum & 0xFFFF);
}

inline void telemetryFinalize(TelemetryPacket& pkt) {
  pkt.packet_type = TELEMETRY_PACKET_TYPE;
  pkt.checksum = 0;
  size_t bodyLen = sizeof(TelemetryPacket) - sizeof(pkt.checksum);
  pkt.checksum = telemetryChecksum((const uint8_t*)&pkt, bodyLen);
}
