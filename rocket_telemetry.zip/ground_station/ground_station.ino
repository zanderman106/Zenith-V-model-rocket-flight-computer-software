// =============================================================================
// ROCKET GROUND STATION
// Board: any Arduino-capable board wired to your second SX1276 LoRa module
// (a spare ESP32, Pico, etc. -- doesn't need a camera or SD card).
//
// Listens for telemetry packets over LoRa and prints them as CSV lines over
// serial, one per line, for a laptop to log or plot:
//   time_ms,state,altitude_m,vspeed_mps,lat,lon,battery_v
//
// If your board doesn't have native USB, wire its UART TX/RX to your
// laptop through the USB-TTL adapter from your parts list.
//
// REQUIRED LIBRARY (install via Library Manager):
//   - LoRa  (by Sandeep Mistry)
//
// telemetry.h in this folder must stay byte-for-byte identical to the copy
// in flight_computer/, or decoding will silently fail (checksum mismatch,
// packets dropped as corrupt). It's the same file on both sides -- if you
// change one, copy it over the other rather than editing separately.
// =============================================================================

#include <Arduino.h>
#include <LoRa.h>

#include "telemetry.h"

// -----------------------------------------------------------------------
// CONFIG -- edit pins to match your wiring
// -----------------------------------------------------------------------
#define LORA_CS_PIN       5
#define LORA_RST_PIN      14
#define LORA_DIO0_PIN     26
#define LORA_FREQ_HZ      915E6
#define LORA_TX_POWER_DBM 17  // unused for RX-only, kept for symmetry with begin()

bool telemetryDecode(const uint8_t* buf, size_t len, TelemetryPacket& out) {
  if (len != sizeof(TelemetryPacket)) return false;
  memcpy(&out, buf, sizeof(TelemetryPacket));
  size_t bodyLen = sizeof(TelemetryPacket) - sizeof(out.checksum);
  uint16_t expected = telemetryChecksum(buf, bodyLen);
  if (expected != out.checksum) return false;
  if (out.packet_type != TELEMETRY_PACKET_TYPE) return false;
  return true;
}

// -----------------------------------------------------------------------
// FLIGHT STATE NAMES -- mirrors the enum in the flight computer sketch
// -----------------------------------------------------------------------
enum FlightState : uint8_t {
  STATE_PAD = 0,
  STATE_POWERED_ASCENT = 1,
  STATE_COAST = 2,
  STATE_APOGEE = 3,
  STATE_DESCENT = 4,
  STATE_LANDED = 5,
};

const char* flightStateName(FlightState s) {
  switch (s) {
    case STATE_PAD: return "PAD";
    case STATE_POWERED_ASCENT: return "POWERED_ASCENT";
    case STATE_COAST: return "COAST";
    case STATE_APOGEE: return "APOGEE";
    case STATE_DESCENT: return "DESCENT";
    case STATE_LANDED: return "LANDED";
    default: return "?";
  }
}

// -----------------------------------------------------------------------
// LORA RADIO
// -----------------------------------------------------------------------
class LoRaLink {
 public:
  bool begin(int csPin, int rstPin, int dio0Pin, long freqHz, int txPowerDbm) {
    LoRa.setPins(csPin, rstPin, dio0Pin);
    _ok = LoRa.begin(freqHz);
    if (_ok) LoRa.setTxPower(txPowerDbm);
    return _ok;
  }

  int receive(uint8_t* buf, size_t maxLen) {
    if (!_ok) return -1;
    int packetSize = LoRa.parsePacket();
    if (packetSize == 0) return 0;
    size_t n = 0;
    while (LoRa.available() && n < maxLen) {
      buf[n++] = LoRa.read();
    }
    return (int)n;
  }

  bool ok() const { return _ok; }

 private:
  bool _ok = false;
};

// -----------------------------------------------------------------------
// MAIN
// -----------------------------------------------------------------------
LoRaLink lora;
uint32_t lastPacketMs = 0;
uint32_t lastWarnMs = 0;

void setup() {
  Serial.begin(115200);
  delay(500);

  bool ok = lora.begin(LORA_CS_PIN, LORA_RST_PIN, LORA_DIO0_PIN, LORA_FREQ_HZ, LORA_TX_POWER_DBM);
  Serial.print("LoRa: ");
  Serial.println(ok ? "ok" : "FAILED -- check wiring/pins above");

  lastPacketMs = millis();
}

void loop() {
  uint8_t buf[64];
  int n = lora.receive(buf, sizeof(buf));

  if (n > 0) {
    TelemetryPacket pkt;
    if (telemetryDecode(buf, n, pkt)) {
      lastPacketMs = millis();
      Serial.printf("%lu,%s,%.2f,%.2f,%.6f,%.6f,%.2f\n",
                    (unsigned long)pkt.time_ms,
                    flightStateName((FlightState)pkt.flight_state),
                    pkt.altitude_m, pkt.vertical_speed_mps,
                    pkt.lat, pkt.lon, pkt.battery_v);
    } else {
      Serial.println("# dropped corrupt packet");
    }
  }

  if (millis() - lastPacketMs > 5000 && millis() - lastWarnMs > 5000) {
    Serial.println("# no telemetry for 5+ seconds");
    lastWarnMs = millis();
  }
}
